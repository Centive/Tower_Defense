# Bitmap Handwriting Font [![Public Domain (CC0)](https://i.creativecommons.org/p/zero/1.0/80x15.png)](https://creativecommons.org/publicdomain/zero/1.0/)
**Version 1***

A simple handwriting font.
Currently contains Roman letters (A-Z + a-z), numbers, and a few symbols (!, ?, and #).
Characters are 32x32.

_This font is public domain [under the CC0](https://creativecommons.org/publicdomain/zero/1.0/)._
